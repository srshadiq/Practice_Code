#include<stdio.h>
#include<string.h>
int main(){
    char num1[1000],num2[1000];
    scanf("%s %s",num1,num2);
    for (int i = 0; i<strlen(num1); i++)
    {
        if(num1[i]==num2[i]){
            num1[i]='0';
        }
        else{
            num1[i]='1';
        }
    }
    printf("%s\n",num1);
    
    return 0;
}